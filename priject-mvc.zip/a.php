<?php
// sesuaikan alamat server, jika perlu beri juga port apache nya
// buka app/config/config.php
// atur alamat server dan database, lebih baik termasuk portnya (jika tifak ada setingan default)
// terdapat konfigurasi database dari mysql dan mariadb
// hiasan dari var_dump di datas layar sebagai informasi halaman, tidak apa jika dihapus. letaknya di app/view/templates/header atau app/controllers
header("Location: http://localhost:8080/project-mvc/public");
exit;